package com.example.se_tp;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


/*
사용자 UI와 XML, 코드, DB에서 자리 번호는 모두 1부터 시작함. (0부터 시작이 아닌)
 */


public class MainActivity extends Activity implements View.OnClickListener{

    public int mySeat=-1;
    public int myState=0;
    public String myID;
    public Button[] seatBtn = new Button[93]; // 인덱스 0 미사용
    Handler handler = new Handler();
    TextView txtview;
    public int[] seatState = new int[93];// 0 = 초기화 , 1 = 공석 , 2= 자리있음,3 = 공석 대기 , 인덱스 0 미사용
    public ArrayList<String> msgNum;
    public int selBtn=-1;
    public int beforeBtn=-1;


    public FirebaseDatabase database; // 데이터베이스 객체
    public DatabaseReference[] seatRef = new DatabaseReference[93]; // 인덱스 0 미사용
    final int[] FBListenerCount = {1};




    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);




            msgNum = new ArrayList<String>();

            for(int i=1; i <= 92; i++){
                seatState[i] = 1;// 초기화
            }
            createButton();
        txtview = (TextView)findViewById(R.id.mySeatView);

        msgNum.add("안쓰는 0번 인덱스"); // msgNum 의 0번 인덱스 무효화 (1번부터 시작하게)
        for(int i=1; i <= 92; i++){
                seatBtn[i].setTag(i);
                seatBtn[i].setOnClickListener(this);
                msgNum.add((i) + "번 자리입니다.");
            }

















        database = FirebaseDatabase.getInstance();


        /*

        try {
            Thread.sleep(10000);
        }
        catch (Exception e) {}
        */



        for (int i = 1; i <= 92; i++) {
            seatRef[i] = database.getReference("seat" + Integer.toString(i));

            Log.d("FBListener", seatRef[i].getKey());


            /*

            try {
                Thread.sleep(100);
            }
            catch (Exception e) {}
            */


            seatRef[i].addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.


                    /*

                    try {
                        Thread.sleep(100);
                    }
                    catch (Exception e) {}
                    */



                    String value = dataSnapshot.getValue(String.class);
                    String key = dataSnapshot.getKey();
                    Log.d("FBListener", "from FB snapshot key : " + key);
                    // 지금 데이터스냅샷이 서로 꼬이는 것 같은데?
                    Log.d("FBListener", "from FB snapshot value : " + value);
                    // 변경된 데이터를 화면에 출력해 준다.

                        /*
                        for(int i = 1; i <= 92; i++) {
                            String buttonID = "seat" + i;
                            int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                            seatBtn[i] = ((Button) findViewById((resID)));
                        }
                        */



                    // int thisSeatNum = Integer.valueOf(FBListenerCount[0]);
                    int thisSeatNum = Integer.valueOf(key.substring(4));
                    String buttonID = "seat" + thisSeatNum;
                    int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                    seatBtn[thisSeatNum] = ((Button) findViewById((resID)));

                    if (value.substring(0, 1).equals("1"))
                    {
                        seatBtn[thisSeatNum].setBackgroundResource(R.drawable.imgbtn1);
                    }
                    else if (value.substring(0, 1).equals("2"))
                    {
                        seatBtn[thisSeatNum].setBackgroundResource(R.drawable.imgbtn2);
                    }
                    else if (value.substring(0, 1).equals("3"))
                    {
                        seatBtn[thisSeatNum].setBackgroundResource(R.drawable.imgbtn3);
                    }
                    else
                    {
                        Log.e("FBListener", "unknown state number");
                    }

                    Log.d("FBListener", "thisSeatNum : " + thisSeatNum + " resID : "
                            + resID + " buttonID : " + buttonID);



                    FBListenerCount[0]++;
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Failed to read value
                    Log.e("error on reading DB", "Failed to read value.",
                            databaseError.toException());
                }
            });



            // 여기 대기 없애면 제대로 안나온다!
            // 왜 대기시간 따라 결과가 바뀌냐??
            /*
            try {
                Thread.sleep(500);
            }
            catch (Exception e) {}
            */



        }




        }

    @Override
    public void onClick(View v)
    {

        // 클릭된 뷰를 버튼으로 받아옴
        Button newButton = (Button) v;

        // 향상된 for문을 사용, 클릭된 버튼을 찾아냄
        for(Button tempButton : seatBtn)
        {
            // 클릭된 버튼을 찾았으면
            if(tempButton == newButton)
            {
                // 위에서 저장한 버튼의 포지션을 태그로 가져옴
                int position = (Integer)v.getTag();
                Message msg = handler.obtainMessage();
                msg.arg1 = position;// 숫자
                selBtn = position;
                handler.sendMessage(msg);// send message to handleMessage
                // 태그로 가져온 포지션을 이용해 리스트에서 출력할 데이터를 꺼내서 토스트 메시지 출력
                Toast.makeText(this, msgNum.get(position), Toast.LENGTH_SHORT).show();
            }
        }
    }
    public class Handler extends android.os.Handler {
        public void handleMessage(Message msg){// 상태에 따라 팝업 or 선택 표시로 이미지 변경
            if(beforeBtn == msg.arg1){// 더블 클릭 했을때 팝업 띄우기
                    if(seatState[msg.arg1] == 1){// 공석
                        Intent intent = new Intent(MainActivity.this, requestPop.class);
                        intent.putExtra("seatNum", msg.arg1);
                        startActivityForResult(intent, 1);
                     }
                    else if((seatState[msg.arg1] == 2) && (mySeat == msg.arg1)){// 자리있음 ,퇴실
                        Intent intent = new Intent(MainActivity.this, outPop.class);
                        intent.putExtra("seatNum", msg.arg1);
                        startActivityForResult(intent, 4);
                    }
                     else if((seatState[msg.arg1] == 2) && (mySeat != msg.arg1)){// 자리있음 ,신고
                        Intent intent = new Intent(MainActivity.this, reportPop.class);
                        intent.putExtra("seatNum", msg.arg1);
                        startActivityForResult(intent, 2);
                     }
                    else if((seatState[msg.arg1] == 3) && (mySeat == msg.arg1)){// 공석대기
                        Intent intent = new Intent(MainActivity.this, waitingPop.class);
                        intent.putExtra("seatNum", msg.arg1);
                        startActivityForResult(intent, 3);
                    }

            }
            else if(beforeBtn != -1) {//이전에 클릭했던 것이 있을때 이전꺼를 초기화 시킨다.
                if(seatState[beforeBtn] == 1){ // 공석
                    seatBtn[beforeBtn].setBackgroundResource(R.drawable.imgbtn1);

                }
                else if(seatState[beforeBtn] == 2){ // 자리있음
                    seatBtn[beforeBtn].setBackgroundResource(R.drawable.imgbtn2);

                }
                else if(seatState[beforeBtn] == 3){ // 공석 대기중
                    seatBtn[beforeBtn].setBackgroundResource(R.drawable.imgbtn3);

                }
                if(seatState[msg.arg1] == 1){ // 공석
                    seatBtn[msg.arg1].setBackgroundResource(R.drawable.secbtn1);

                }
                else if(seatState[msg.arg1] == 2){ // 자리있음
                    seatBtn[msg.arg1].setBackgroundResource(R.drawable.setbtn2);

                }
                else if(seatState[msg.arg1] == 3){ // 공석 대기중
                    seatBtn[msg.arg1].setBackgroundResource(R.drawable.setbtn3);

                }
                beforeBtn = msg.arg1;
            }
            else{
                beforeBtn = msg.arg1;
                seatBtn[msg.arg1].setBackgroundResource(R.drawable.secbtn1);

            }

        }
    }
    public void createButton(){
        for(int i = 1; i <= 92; i++) {
            String buttonID = "seat" + i;
            int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
            seatBtn[i] = ((Button) findViewById((resID)));
        }
        /*
        seatBtn[0] = (Button) findViewById(R.id.seat1);
        seatBtn[1] = (Button) findViewById(R.id.seat2);
        seatBtn[2] = (Button) findViewById(R.id.seat3);
        seatBtn[3] = (Button) findViewById(R.id.seat4);
        seatBtn[4] = (Button) findViewById(R.id.seat5);
        seatBtn[5] = (Button) findViewById(R.id.seat6);
        seatBtn[6] = (Button) findViewById(R.id.seat7);
        seatBtn[7] = (Button) findViewById(R.id.seat8);
        seatBtn[8] = (Button) findViewById(R.id.seat9);
        seatBtn[9] = (Button) findViewById(R.id.seat10);
        seatBtn[10] = (Button) findViewById(R.id.seat11);
        seatBtn[11] = (Button) findViewById(R.id.seat12);
        seatBtn[12] = (Button) findViewById(R.id.seat13);
        seatBtn[13] = (Button) findViewById(R.id.seat14);
        seatBtn[14] = (Button) findViewById(R.id.seat15);
        seatBtn[15] = (Button) findViewById(R.id.seat16);
        seatBtn[16] = (Button) findViewById(R.id.seat17);
        seatBtn[17] = (Button) findViewById(R.id.seat18);
        seatBtn[18] = (Button) findViewById(R.id.seat19);
        seatBtn[19] = (Button) findViewById(R.id.seat20);
        seatBtn[20] = (Button) findViewById(R.id.seat21);
        seatBtn[21] = (Button) findViewById(R.id.seat22);
        seatBtn[22] = (Button) findViewById(R.id.seat23);
        seatBtn[23] = (Button) findViewById(R.id.seat24);
        seatBtn[24] = (Button) findViewById(R.id.seat25);
        seatBtn[25] = (Button) findViewById(R.id.seat26);
        seatBtn[26] = (Button) findViewById(R.id.seat27);
        seatBtn[27] = (Button) findViewById(R.id.seat28);
        seatBtn[28] = (Button) findViewById(R.id.seat29);
        seatBtn[29] = (Button) findViewById(R.id.seat30);
        seatBtn[30] = (Button) findViewById(R.id.seat31);
        seatBtn[31] = (Button) findViewById(R.id.seat32);
        seatBtn[32] = (Button) findViewById(R.id.seat33);
        seatBtn[33] = (Button) findViewById(R.id.seat34);
        seatBtn[34] = (Button) findViewById(R.id.seat35);
        seatBtn[35] = (Button) findViewById(R.id.seat36);
        seatBtn[36] = (Button) findViewById(R.id.seat37);
        seatBtn[37] = (Button) findViewById(R.id.seat38);
        seatBtn[38] = (Button) findViewById(R.id.seat39);
        seatBtn[39] = (Button) findViewById(R.id.seat40);
        seatBtn[40] = (Button) findViewById(R.id.seat41);
        seatBtn[41] = (Button) findViewById(R.id.seat42);
        seatBtn[42] = (Button) findViewById(R.id.seat43);
        seatBtn[43] = (Button) findViewById(R.id.seat44);
        seatBtn[44] = (Button) findViewById(R.id.seat45);
        seatBtn[45] = (Button) findViewById(R.id.seat46);
        seatBtn[46] = (Button) findViewById(R.id.seat47);
        seatBtn[47] = (Button) findViewById(R.id.seat48);
        seatBtn[48] = (Button) findViewById(R.id.seat49);
        seatBtn[49] = (Button) findViewById(R.id.seat50);
        seatBtn[50] = (Button) findViewById(R.id.seat51);
        seatBtn[51] = (Button) findViewById(R.id.seat52);
        seatBtn[52] = (Button) findViewById(R.id.seat53);
        seatBtn[53] = (Button) findViewById(R.id.seat54);
        seatBtn[54] = (Button) findViewById(R.id.seat55);
        seatBtn[55] = (Button) findViewById(R.id.seat56);
        seatBtn[56] = (Button) findViewById(R.id.seat57);
        seatBtn[57] = (Button) findViewById(R.id.seat58);
        seatBtn[58] = (Button) findViewById(R.id.seat59);
        seatBtn[59] = (Button) findViewById(R.id.seat60);
        seatBtn[60] = (Button) findViewById(R.id.seat61);
        seatBtn[61] = (Button) findViewById(R.id.seat62);
        seatBtn[62] = (Button) findViewById(R.id.seat63);
        seatBtn[63] = (Button) findViewById(R.id.seat64);
        seatBtn[64] = (Button) findViewById(R.id.seat65);
        seatBtn[65] = (Button) findViewById(R.id.seat66);
        seatBtn[66] = (Button) findViewById(R.id.seat67);
        seatBtn[67] = (Button) findViewById(R.id.seat68);
        seatBtn[68] = (Button) findViewById(R.id.seat69);
        seatBtn[69] = (Button) findViewById(R.id.seat70);
        seatBtn[70] = (Button) findViewById(R.id.seat71);
        seatBtn[71] = (Button) findViewById(R.id.seat72);
        seatBtn[72] = (Button) findViewById(R.id.seat73);
        seatBtn[73] = (Button) findViewById(R.id.seat74);
        seatBtn[74] = (Button) findViewById(R.id.seat75);
        seatBtn[75] = (Button) findViewById(R.id.seat76);
        seatBtn[76] = (Button) findViewById(R.id.seat77);
        seatBtn[77] = (Button) findViewById(R.id.seat78);
        seatBtn[78] = (Button) findViewById(R.id.seat79);
        seatBtn[79] = (Button) findViewById(R.id.seat80);
        seatBtn[80] = (Button) findViewById(R.id.seat81);
        seatBtn[81] = (Button) findViewById(R.id.seat82);
        seatBtn[82] = (Button) findViewById(R.id.seat83);
        seatBtn[83] = (Button) findViewById(R.id.seat84);
        seatBtn[84] = (Button) findViewById(R.id.seat85);
        seatBtn[85] = (Button) findViewById(R.id.seat86);
        seatBtn[86] = (Button) findViewById(R.id.seat87);
        seatBtn[87] = (Button) findViewById(R.id.seat88);
        seatBtn[88] = (Button) findViewById(R.id.seat89);
        seatBtn[89] = (Button) findViewById(R.id.seat90);
        seatBtn[90] = (Button) findViewById(R.id.seat91);
        seatBtn[91] = (Button) findViewById(R.id.seat92);
        */
    }// allign by findVIewByID

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==1){// 신청
            if(resultCode==RESULT_OK){
                //데이터 받기

                int result = data.getIntExtra("seatNum",1);
                seatBtn[result].setBackgroundResource(R.drawable.setbtn2);
                seatState[result] = 2;
                mySeat = result;
                txtview.setText("사용자의 자리 : "+ (result) + "번 ");
            }
        }
        else if(requestCode==2){// 신고
            if(resultCode==RESULT_OK){
                //데이터 받기

                int result = data.getIntExtra("seatNum",1);
                seatBtn[result].setBackgroundResource(R.drawable.setbtn3);
                seatState[result] = 3;

            }
        } else if(requestCode==3){// 복귀신고
            if(resultCode==RESULT_OK){
                //데이터 받기

                int result = data.getIntExtra("seatNum",1);
                seatBtn[result].setBackgroundResource(R.drawable.setbtn2);
                seatState[result] = 2;

            }
            if(resultCode==RESULT_CANCELED){
                //데이터 받기

                int result = data.getIntExtra("seatNum",1);
                seatBtn[result].setBackgroundResource(R.drawable.setbtn3);
                seatState[result] = 3;

            }
        }
        else if(requestCode==4){// 퇴실
            if(resultCode==RESULT_OK){
                //데이터 받기

                int result = data.getIntExtra("seatNum",1);
                seatBtn[result].setBackgroundResource(R.drawable.secbtn1);
                seatState[result] = 1;
                mySeat = -1;
                txtview.setText("사용자의 자리 : ");
            }
        }
    }
    public void setSeatUI(){// seat State에 따라서 전체 gui 최신화

    }


}


